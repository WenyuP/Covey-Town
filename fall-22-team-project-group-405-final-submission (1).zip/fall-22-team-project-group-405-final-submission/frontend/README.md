# Covey.Town Frontend App

Please see the `README.md` in the repository base for information about this project.

This frontend is created using the [create react app](https://create-react-app.dev) toolchain. You
can start a development server by running `npm start`. To create a production build, run
`npm run build`.
